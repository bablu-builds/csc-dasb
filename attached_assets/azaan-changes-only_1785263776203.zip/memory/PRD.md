# AZAAN CSC — Import PRD

## Original problem statement
Import code in this repo. User then clarified: run the existing Replit project *as-is* with **demo data** (no Firebase credentials).

## Product summary
**AZAAN Communication Tour and Travel** — a staff portal for a travel / communication-services agency. Owners/staff track customer work orders (PAN, Aadhar, DL, bill payments, ticket booking, etc.), earnings, dues and financial-service transactions (AEPS, Electric Recharge, Money Transfer). Role-based access: **Owner** sees all financials + Reports + Staff Management; **Staff** sees the operational view only (unless granted financial-services access).

## Architecture (as-imported)
- **Workspace:** pnpm workspaces at `/app`
- **Frontend:** `/app/artifacts/azaan-csc` — React 19 + Vite 7 + Tailwind CSS 4 + shadcn/ui + wouter routing (port **3000**)
- **API server:** `/app/artifacts/api-server` — Express 5 (currently unused in demo mode; supervisor `backend` program is a no-op)
- **Original data layer:** Firebase Auth + Firestore
- **Demo mode swap:** Vite aliases `firebase/app`, `firebase/auth`, `firebase/firestore` → local in-memory mocks under `src/lib/mock/`. Data is persisted to `localStorage` so it survives reloads.

## What's been implemented in this session (2026-07-28)
- **In-memory Firestore mock** (`src/lib/mock/firebase-firestore.ts`) covering `collection`, `doc`, `query`, `where`, `orderBy`, `limit`, `getDoc`, `getDocs`, `setDoc`, `addDoc`, `updateDoc`, `deleteDoc`, `onSnapshot`, `writeBatch`, `arrayUnion`, `Timestamp`.
- **In-memory Firebase Auth mock** (`src/lib/mock/firebase-auth.ts`) covering sign-in / sign-up / sign-out / password reset / persistence.
- **Firebase App mock** (`src/lib/mock/firebase-app.ts`) supporting the secondary-app pattern used by `createStaffAccount`.
- **Demo seed** (`src/lib/mock/demo-seed.ts`): one owner + one staff account, shop settings, 15 default categories, 15 work entries across all statuses/dates, 3 AEPS withdrawals, 2 electric recharges, 2 money transfers, 10 Quick Action Work entries.
- **Vite alias wiring** in `vite.config.ts` gated by `VITE_DEMO_MODE=true`.
- **Auto sign-in** at app boot if no session exists (`src/main.tsx`).
- **Supervisor** rewired: `frontend` runs `pnpm --filter @workspace/azaan-csc run dev` on port 3000 with `VITE_DEMO_MODE=true`; `backend` and `mongodb` disabled (not needed).
- **Feature: Quick Action Work** — new page at `/quick-work` accessible to both Owner and Staff. Adds a sidebar nav item, a `quickActionWork` Firestore collection, `createQuickAction` / `subscribeToQuickActions` helpers in `src/lib/firestore.ts`, and a `QuickWorkPage` with a category select (Printout / Lamination / Xerox / PVC / Print / Photo Print / Other), optional customer name, required amount, auto date/time and Added By, plus a search + date range filter. Dashboard now sums Quick Work into Today's / This-Month earnings and profits (and the 7-day chart). Reports gets a new "Quick Work" tab with category breakdown, chart, table and CSV export.

## Personas
- **Owner** (`Azaan Owner`) — full dashboard, reports, staff management, financial services.
- **Staff** (`Ravi Staff`) — pending work + activity view only, financial services enabled in the seed.

## Core requirements (static)
- Runs offline / without external credentials in demo mode.
- Preserves the full UX: routing, role gates, Firestore-style realtime subscriptions.
- All demo data persists across reloads via `localStorage`.

## Prioritized backlog / next steps
- P1: Add a visible **“Demo mode”** banner + a **“Reset demo data”** button (currently users must clear `localStorage` manually to re-seed).
- P1: Wire the real Firebase config (drop `VITE_DEMO_MODE`, add the six `VITE_FIREBASE_*` env vars) when the user is ready to go live.
- P2: Deploy the Express API server if any server-side logic is needed later (currently a no-op in supervisor).
- P2: Add a “Login as Staff” shortcut on the login page for the demo.

## Run / operate
- Preview URL is served on port 3000 through the platform ingress.
- Restart: `sudo supervisorctl restart frontend`
- Logs: `/var/log/supervisor/frontend.{out,err}.log`
- Toggle real Firebase: set `VITE_DEMO_MODE=false` (or remove it) in `/etc/supervisor/conf.d/supervisord.conf` `[program:frontend]` and provide the `VITE_FIREBASE_*` env vars, then `supervisorctl restart frontend`.
