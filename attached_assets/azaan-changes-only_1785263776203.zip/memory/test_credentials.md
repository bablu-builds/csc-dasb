# Demo Test Credentials

The app is running in **demo mode** (`VITE_DEMO_MODE=true`). Data is stored
in-memory + `localStorage`; no external Firebase project is used.

The demo owner is **auto-logged in** on first load. To sign in manually (e.g. as
the staff account), open `/logout` or click **Logout**, then use the credentials
below on the Login page.

## Accounts

| Role   | Email                | Password  | Notes                                                 |
|--------|----------------------|-----------|-------------------------------------------------------|
| Owner  | owner@demo.local     | demo1234  | Auto-logged in on first visit. Full access.           |
| Staff  | staff@demo.local     | demo1234  | Financial-services access is enabled in the seed.     |

## Resetting demo data
Open the browser DevTools console and run:

```js
localStorage.removeItem('azaan_demo_firestore_v1');
localStorage.removeItem('azaan_demo_users_v1');
localStorage.removeItem('azaan_demo_currentUid_v1');
location.reload();
```

The app will re-seed the demo owner, staff, categories and work entries on the
next load.
